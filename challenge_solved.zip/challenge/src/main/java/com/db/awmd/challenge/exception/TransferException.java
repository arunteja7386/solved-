package com.db.awmd.challenge.exception;

public class TransferException extends RuntimeException {

	  public TransferException(String message) {
	    super(message);
	  }

}
